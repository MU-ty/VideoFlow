# EGDR 压机身份控制样例

这四段三秒源片由 Blender 4.3 渲染。S1 与 S2 复用同一套压机几何、材质和轮件动画，摄像机位置不同。S3 将双青条纹换成橙色菱形标记，同时保留外观近似的手轮。S4 只含工具箱。渲染源码在 `render_press.py`。

| 镜头 | 编辑范围 | 判断依据 |
|---|---|---|
| S1 | 应重生成 | 双青条纹机身与其手轮同框，已有声明 |
| S2 | 应重生成 | 同一台压机的另一角度，分镜文字省略身份和轮件，未声明 |
| S3 | 应复用 | 橙色菱形机身及其琥珀色手轮 |
| S4 | 应复用 | 灰色工具箱，无压机 |

人工标签在 `cases.json` 的 `gold` 字段，仅用于评估。模型问题在 `questions.json`，不含标签。Checklist 分别运行分镜文字版本和带帧观察版本。帧观察保留可见的标志和零件，不提供应重生成或应复用的判断。

## 在学校服务器运行

启动之前已验证的 Ollama 服务，确认 `qwen2.5vl:7b-ctx8k` 已创建。解压后执行以下命令。参数是 VideoFlow 仓库路径。

```bash
bash "$HOME/egdr-press-control-v1/run_probe.sh" "$HOME/VideoFlow-workflow-pair"
```

脚本输出路径中包含 `protocol.json`、`report.json`、`responses.jsonl` 与四格抽帧。对比 `checklist_text`、`checklist_union`、`union_plus_vision` 和 `union_plus_verified` 的选镜、漏选和多选。如果 Checklist 并集已选中 S2，按实际结果报告。如果直接视觉并集未误选 S3，当前案例无法展示复核纠正这一误选。

这是新制作的合成控制样例，用来测试选镜与零件归属。它只包含一个场景和一条编辑，不涉及 H3 提交或重生成。可将它作为诊断样例。论文里的泛化结论仍需另用独立源片验证。
