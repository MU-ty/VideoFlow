"""Render the four controlled source clips. Run with Blender 4.3 in background mode."""
import math
from pathlib import Path
import sys

import bpy
from mathutils import Vector

out = Path(sys.argv[sys.argv.index('--') + 1])
out.mkdir(parents=True, exist_ok=True)
only = sys.argv[sys.argv.index('--') + 2:] or ['S1', 'S2', 'S3', 'S4']
scene = bpy.context.scene
scene.render.engine = 'BLENDER_WORKBENCH'
scene.render.resolution_x = 768
scene.render.resolution_y = 432
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.fps = 12
scene.frame_start = 1
scene.frame_end = 36
scene.view_settings.view_transform = 'Standard'
shade = scene.display.shading
shade.light = 'STUDIO'
shade.studiolight_rotate_z = 0.5
shade.color_type = 'MATERIAL'
shade.show_shadows = True
shade.show_cavity = True
shade.cavity_type = 'BOTH'
shade.show_specular_highlight = True
shade.background_type = 'WORLD'

def mat(name, color):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    return m

cream = mat('cream', (.82, .74, .56))
teal = mat('teal', (.025, .43, .40))
amber = mat('amber', (.80, .25, .030))
amber_dark = mat('amber hub', (.49, .13, .020))
steel = mat('steel', (.48, .55, .59))
charcoal = mat('charcoal', (.09, .12, .15))
wood = mat('bench', (.44, .25, .125))
floor = mat('floor', (.21, .26, .28))
wall = mat('back', (.24, .31, .34))
orange = mat('orange diamond', (.93, .28, .015))
gray = mat('toolbox', (.29, .34, .38))

def finish(obj, material, bevel):
    obj.data.materials.append(material)
    if bevel:
        b = obj.modifiers.new('Machined edges', 'BEVEL')
        b.width = bevel
        b.segments = 3
        obj.modifiers.new('Corner normals', 'WEIGHTED_NORMAL')
    return obj

def box(name, at, size, material, bevel=.025):
    bpy.ops.mesh.primitive_cube_add(size=1, location=at)
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    return finish(obj, material, bevel)

def cyl(name, at, radius, depth, material, horizontal=False):
    bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=radius, depth=depth, location=at,
                                      rotation=(math.pi/2, 0, 0) if horizontal else (0, 0, 0))
    obj = bpy.context.object
    obj.name = name
    return finish(obj, material, .007)

def bench():
    box('wooden worktop', (0, 0, -.10), (3.95, 1.9, .22), wood, .06)
    for x in (-1.65, 1.65):
        for y in (-.64, .64):
            box('bench leg', (x, y, -.58), (.13, .13, .94), charcoal)
    for i in range(5):
        box('plank seam', (0, -.76 + i*.35, .011), (3.75, .014, .003), wood, 0)
    box('shop floor', (0, 0, -1.15), (200, 200, .20), floor, 0)
    box('shop wall', (0, 3.5, 1.8), (14, .2, 6), wall, 0)

def press(decoy):
    box('cast iron base', (0, .01, .12), (1.92, 1.06, .22), cream, .06)
    box('upright', (-.68, .12, .93), (.43, .65, 1.59), cream, .09)
    box('upper head', (-.02, .04, 1.65), (1.79, .71, .44), cream, .09)
    box('lower platen', (.47, .07, .35), (.78, .65, .115), steel)
    cyl('steel ram', (.47, .07, 1.17), .12, .67, steel)
    cyl('ram end', (.47, .07, .83), .175, .075, charcoal)
    if decoy:
        emblem = box('orange diamond identity marker', (-.38, -.32, 1.65), (.245, .024, .245), orange, .008)
        emblem.rotation_euler.y = math.pi/4
    else:
        for z in (1.62, 1.73):
            box('teal identity stripe', (-.37, -.319, z), (.86, .014, .055), teal, .003)
    center = Vector((.52, -.56, 1.65))
    cyl('handwheel mounting shaft', (.52, -.42, 1.65), .075, .27, steel, True)
    hub = bpy.data.objects.new('handwheel spin', None)
    bpy.context.collection.objects.link(hub)
    hub.location = center
    bpy.context.view_layer.update()

    def attach(obj):
        obj.parent = hub
        obj.matrix_parent_inverse = hub.matrix_world.inverted()

    bpy.ops.mesh.primitive_torus_add(major_segments=64, minor_segments=16,
        location=center, rotation=(math.pi/2, 0, 0), major_radius=.326, minor_radius=.037)
    attach(finish(bpy.context.object, amber, 0))
    for i in range(32):
        a = 2*math.pi*i/32
        loc = center + Vector((.343*math.cos(a), 0, .343*math.sin(a)))
        obj = box('ribbed grip', loc, (.059, .082, .033), amber, .008)
        obj.rotation_euler.y = -a
        attach(obj)
    for i in range(3):
        a = 2*math.pi*i/3
        loc = center + Vector((.177*math.cos(a), 0, .177*math.sin(a)))
        obj = box('wheel spoke', loc, (.29, .06, .064), amber, .012)
        obj.rotation_euler.y = -a
        attach(obj)
    attach(cyl('handwheel hub', center, .099, .10, amber_dark, True))
    attach(cyl('hub bolt', center + Vector((0, -.058, 0)), .044, .022, steel, True))
    for frame, angle in ((1, 0), (36, math.pi*.9)):
        hub.rotation_euler.y = angle
        hub.keyframe_insert(data_path='rotation_euler', frame=frame)

def toolbox():
    box('gray toolbox body', (0, -.06, .37), (1.65, .91, .61), gray, .075)
    box('toolbox lid', (0, -.06, .72), (1.73, .96, .17), charcoal, .06)
    for x in (-.6, .6):
        box('metal latch', (x, -.56, .67), (.155, .09, .21), steel)
    for x in (-.23, .23):
        box('handle mount', (x, -.08, .86), (.09, .10, .16), charcoal)
    box('carry handle', (0, -.08, .94), (.53, .10, .09), charcoal)

views = {
 'S1': ((.80, -4.7, 2.17), (.02, -.09, 1.22), 52),
 'S2': ((-2.27, -4.30, 2.43), (.07, -.09, 1.22), 54),
 'S3': ((.86, -4.76, 2.17), (.02, -.09, 1.22), 52),
 'S4': ((1.70, -3.5, 1.98), (0, -.06, .55), 48),
}
for shot in only:
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    bench()
    if shot == 'S4':
        toolbox()
    else:
        press(shot == 'S3')
    start, target, focal_length = views[shot]
    bpy.ops.object.camera_add()
    cam = bpy.context.object
    cam.data.lens = focal_length
    scene.camera = cam
    for frame, shift in ((1, 0), (36, .15)):
        cam.location = Vector(start) + Vector((shift, .03*shift, .04*shift))
        cam.rotation_euler = (Vector(target) - cam.location).to_track_quat('-Z', 'Y').to_euler()
        cam.keyframe_insert(data_path='location', frame=frame)
        cam.keyframe_insert(data_path='rotation_euler', frame=frame)
    (out/shot).mkdir(exist_ok=True)
    scene.render.filepath = str(out/shot/'frame-')
    bpy.ops.render.render(animation=True)
