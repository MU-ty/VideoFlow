#!/usr/bin/env bash
set -euo pipefail
fixture_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo_dir=${1:-"$HOME/VideoFlow-workflow-pair"}
out_dir=${2:-"$fixture_dir/results-$(date +%Y%m%d-%H%M%S)"}
ffmpeg_dir="$HOME/apps/videoflow-ffmpeg/ffmpeg-7.0.2-amd64-static"
if [[ -x "$ffmpeg_dir/ffmpeg" && -x "$ffmpeg_dir/ffprobe" ]]; then
  export PATH="$ffmpeg_dir:$PATH"
fi
python3 -u "$repo_dir/research/dependency_probe/vision_probe.py" \
  --cases "$fixture_dir/cases.json" \
  --visibility-questions "$fixture_dir/questions.json" \
  --verify-visual \
  --vision-model "${EGDR_VISION_MODEL:-qwen2.5vl:7b-ctx8k}" \
  --output "$out_dir"
printf 'Results: %s\n' "$out_dir"
